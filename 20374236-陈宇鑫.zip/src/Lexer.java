
import java.util.ArrayList;
import java.util.List;

class Token {
    private TokenType type;
    private String value;

    public Token(TokenType type, String value) {
        this.type = type;
        this.value = value;
    }

    public TokenType getType() {
        return type;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "{" + "Type: " + type + ", Value: '" + value + "'}";
    }
}
class Constants {
    public static final List<String> Keyword;

    static {
        // 初始化字符串列表
        Keyword = new ArrayList<>();
        Keyword.add("BEGIN");
        Keyword.add("END");
        Keyword.add("IF");
        Keyword.add("ELSE");
        Keyword.add("THEN");
    }
}
enum TokenType {
    //关键字
    KEYWORD,
    //保留字
    IDENTIFIER,
    //数字
    NUMBER,
    //操作符
    OPERATOR,
    //分号
    SEMISY,
    //逗号
    COMMASY,
    //冒号
    COLONSY,
    //左扩号
    LPARSY,
    //右扩号
    RPARSY,
    //斜线
    DIVISY,
    EQU,
    QUOTE,
    DOUBLE_QUOTE,
}

class Lexer {
    private String input;
    private int position;

    public Lexer(String input) {
        this.input = input;
        this.position = 0;
    }

    public List<Token> tokenize() {
        List<Token> tokens = new ArrayList<>();

        while (position < input.length()) {
            char currentChar = input.charAt(position);
            //如果读到的是空字符
            if (Character.isWhitespace(currentChar)) {
                position++;
                continue;
            }
            //如果读到单行注释
            if(isDivi(currentChar)){
                if(isDivi(input.charAt(position+1))){
                    position+=2;
                    while(input.charAt(position)!='\n'){
                        position++;
                    }
                    continue;
                }
            }
            /*

             */
            //如果读到多行注释
            if(isDivi(currentChar)){
                if(input.charAt(position+1)=='*'){
                    position+=2;
                    while(input.charAt(position)!='*'&&input.charAt(position+1)!='/'){
                        position++;
                    }
                    position+=2;
                    continue;
                }
            }
            //如果读到的是字母
            if (Character.isLetter(currentChar)) {
                tokens.add(scanString());
                continue;
            }
            //如果读到的是数字
            if (Character.isDigit(currentChar)) {
                tokens.add(scanNumber());
                continue;
            }
            //如果读到的是操作符
            if (isOperator(currentChar)) {
                tokens.add(scanOperator());
                continue;
            }
            //如果读到的是左括号
            if(isLpar(currentChar)){
                tokens.add(scanLpar());
                continue;
            }
            //如果读到的是右括号
            if(isRpar(currentChar)){
                tokens.add(scanRpar());
                continue;
            }
            //如果读到的是分号
            if(isSemi(currentChar)){
                tokens.add(scanSemi());
                continue;
            }
            //如果读到的是冒号
            if(isColon(currentChar)){
                tokens.add(scanColon());
                continue;
            }
            //如果读到的是逗号
            if(isComma(currentChar)){
                tokens.add(scanComma());
                continue;
            }
            //如果读到的是等号
            if(isEqu(currentChar)){
                tokens.add(scanEqu());
                continue;
            }
            if (isQuote(currentChar)) {
                tokens.add(scanQuote());
                continue;
            }
            if (isDoubleQuote(currentChar)) {
                tokens.add(scanDoubleQuote());
                continue;
            }
            position++;
        }

        return tokens;
    }

    //判断是否是斜线
    private boolean isDivi(char ch){return ch=='/';}
    //判断是否是分号
    private boolean isSemi(char ch){return ch==';';}
    private boolean isQuote(char ch) {
        return ch == '\'';
    }
    private boolean isDoubleQuote(char ch) {
        return ch == '"';
    }
    //判断是否是等号
    private boolean isEqu(char ch){return ch=='=';}
    //判断是否是逗号
    private boolean isComma(char ch){return ch==',';}
    //判断是否是冒号
    private boolean isColon(char ch){return ch==':';}
    //判断是否是左扩号
    private boolean isLpar(char ch){return ch=='(';}
    //判断是否是右扩号
    private boolean isRpar(char ch){return ch==')';}
    private boolean isOperator(char ch) {
        return ch == '+' || ch == '-' || ch == '*' || ch == '/';
    }
    //读分号
    private Token scanSemi(){
        char semi=input.charAt(position);
        position++;
        return new Token(TokenType.SEMISY,String.valueOf(semi));
    }
    private Token scanQuote() {
        char quote = input.charAt(position);
        position++;
        return new Token(TokenType.QUOTE, String.valueOf(quote));
    }
    private Token scanDoubleQuote() {
        char doubleQuote = input.charAt(position);
        position++;
        return new Token(TokenType.DOUBLE_QUOTE, String.valueOf(doubleQuote));
    }
    //读等号
    private Token scanEqu(){
        char equ=input.charAt(position);
        position++;
        return new Token(TokenType.EQU,String.valueOf(equ));
    }
    //读逗号
    private Token scanComma(){
        char comma=input.charAt(position);
        position++;
        return new Token(TokenType.COMMASY,String.valueOf(comma));
    }
    //读冒号
    private Token scanColon(){
        char colon=input.charAt(position);
        position++;
        return new Token(TokenType.COLONSY,String.valueOf(colon));
    }
    //读左扩号
    private Token scanLpar(){
        char parens=input.charAt(position);
        position++;
        return new Token(TokenType.LPARSY,String.valueOf(parens));
    }
    //读右扩号
    private Token scanRpar(){
        char parens=input.charAt(position);
        position++;
        return new Token(TokenType.RPARSY,String.valueOf(parens));
    }
    //读标识符
    private Token scanString() {
        StringBuilder identifier = new StringBuilder();
        char currentChar = input.charAt(position);
        //一直向标识符中加入字母或数字直到遇到非字母数字
        while (Character.isLetterOrDigit(currentChar)) {
            identifier.append(currentChar);
            position++;
            //如果这句话已经读完则直接退出
            if (position >= input.length()) {
                break;
            }
            currentChar = input.charAt(position);
        }
        String temp=identifier.toString();
        if(Constants.Keyword.contains(temp)){
            return new Token(TokenType.KEYWORD, temp);
        }
        else{
            return new Token(TokenType.IDENTIFIER, temp);
        }

    }
    //读数字串
    private Token scanNumber() {
        StringBuilder number = new StringBuilder();
        char currentChar = input.charAt(position);

        while (Character.isDigit(currentChar)) {
            number.append(currentChar);
            position++;
            if (position >= input.length()) {
                break;
            }
            currentChar = input.charAt(position);
        }

        return new Token(TokenType.NUMBER, number.toString());
    }
    //读操作符
    private Token scanOperator() {
        char operator = input.charAt(position);
        position++;
        return new Token(TokenType.OPERATOR, String.valueOf(operator));
    }
}

