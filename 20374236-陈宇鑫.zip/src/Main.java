// 按两次 Shift 打开“随处搜索”对话框并输入 `show whitespaces`，
// 然后按 Enter 键。现在，您可以在代码中看到空格字符。

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        // 当文本光标位于高亮显示的文本处时按 Alt+Enter，
        // 可查看 IntelliJ IDEA 对于如何修正该问题的建议。
        Scanner scanner=new Scanner(System.in);
        BufferedReader reader=new BufferedReader(new FileReader("./src/test.txt"));
        StringBuilder content=new StringBuilder();
        String line;
        while((line=reader.readLine())!=null){
            content.append(line);
            content.append(System.lineSeparator());
        }
        System.out.println(content);
        Lexer lexer=new Lexer(content.toString());

        List<Token> words=lexer.tokenize();
        for (int i=0;i<words.size();i++){
            System.out.println(words.get(i));
        }
    }
}